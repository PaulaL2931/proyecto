package edu.uptc.Excepciones;

public class AsesorNoAutorizadoException extends RuntimeException {
    public AsesorNoAutorizadoException(String id) {
        super("El usuario con ID '" + id + "' no tiene permisos de asesor.");
    }
}