package edu.uptc.Excepciones;

public class DatoDuplicadoException extends RuntimeException {
    public DatoDuplicadoException(String tipo, String valor) {
        super("Ya existe un " + tipo + " con el valor '" + valor + "'.");
    }
}