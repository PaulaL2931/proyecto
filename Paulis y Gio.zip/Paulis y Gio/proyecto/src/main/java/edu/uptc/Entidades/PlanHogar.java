package edu.uptc.Entidades;

import edu.uptc.Entidades.Enums.TipoTv;
import java.time.LocalDate;

public class PlanHogar extends Plan {
    private TipoTv tvTipo;
    private int megasInternet;

    public PlanHogar(String id, String usuarioId, LocalDate fechaAdquisicion, double valor,
                     double descuentoMensualPct, TipoTv tvTipo, int megasInternet) {
        super(id, usuarioId, fechaAdquisicion, valor, descuentoMensualPct);
        this.tvTipo = tvTipo;
        this.megasInternet = megasInternet;
    }

    public TipoTv getTvTipo() {
        return tvTipo;
    }

    public int getMegasInternet() {
        return megasInternet;
    }
}