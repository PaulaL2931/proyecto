package edu.uptc.Entidades;

import java.time.LocalDate;

public class Sugerencia extends Solicitud {
    private int nivelImportancia;

    public Sugerencia(String id, String usuarioId, String planId, LocalDate fechaRegistro, String descripcion) {
        super(id, usuarioId, planId, fechaRegistro, descripcion);
        this.nivelImportancia = 1;
    }

    public void ajustarImportancia(int nuevoNivel) {
        this.nivelImportancia = nuevoNivel;
    }
    public int getNivelImportancia() {
        return nivelImportancia;
    }
}