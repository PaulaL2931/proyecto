package edu.uptc.Utilidades;

import java.util.concurrent.atomic.AtomicInteger;

public class GeneradorId {
    private static final AtomicInteger contadorPlanes = new AtomicInteger(1000);
    private static final AtomicInteger contadorSolicitudes = new AtomicInteger(5000);

    public static String generarIdPlan() {
        return "PLAN-" + contadorPlanes.getAndIncrement();
    }

    public static String generarIdSolicitud() {
        return "PQRS-" + contadorSolicitudes.getAndIncrement();
    }
}