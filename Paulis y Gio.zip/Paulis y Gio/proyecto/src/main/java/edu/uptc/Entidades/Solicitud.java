package edu.uptc.Entidades;

import java.time.LocalDate;

public abstract class Solicitud {
    protected String id;
    protected String usuarioId;
    protected String planId;
    protected LocalDate fechaRegistro;
    protected String descripcion;

    public Solicitud(String id, String usuarioId, String planId, LocalDate fechaRegistro, String descripcion) {
        this.id = id;
        this.usuarioId = usuarioId;
        this.planId = planId;
        this.fechaRegistro = fechaRegistro;
        this.descripcion = descripcion;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(String usuarioId) {
        this.usuarioId = usuarioId;
    }

    public String getPlanId() {
        return planId;
    }

    public void setPlanId(String planId) {
        this.planId = planId;
    }

    public LocalDate getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(LocalDate fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}