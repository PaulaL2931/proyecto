package edu.uptc.Excepciones;

public class SolicitudNoEncontradaException extends RuntimeException {
    public SolicitudNoEncontradaException(String id) {
        super("Solicitud con ID '" + id + "' no existe.");
    }
}