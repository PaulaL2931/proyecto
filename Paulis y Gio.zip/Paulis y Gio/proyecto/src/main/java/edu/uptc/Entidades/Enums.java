package edu.uptc.Entidades;

public final class Enums {
    private Enums() {}

    public static enum Rol {
        CLIENTE,
        ASESOR
    }

    public static enum TipoTv {
        DIGITAL,
        ANALOGA
    }
}
