package edu.uptc.Servicios;

import edu.uptc.Entidades.*;
import edu.uptc.Excepciones.*;
import edu.uptc.Utilidades.GeneradorId;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ServicioSolicitud {

    public String crearPeticion(Plan plan, String userId, String descripcion) throws CampoInvalidoException {
        validar(plan, userId, descripcion);
        Peticion p = new Peticion(GeneradorId.generarIdSolicitud(), userId, plan.getId(), LocalDate.now(), descripcion);
        plan.addSolicitud(p);
        return p.getId();
    }

    public String crearQueja(Plan plan, String userId, String descripcion, int nivel) throws CampoInvalidoException {
        validar(plan, userId, descripcion);
        Queja q = new Queja(GeneradorId.generarIdSolicitud(), userId, plan.getId(), LocalDate.now(), descripcion, nivel);
        plan.addSolicitud(q);
        return q.getId();
    }

    public String crearReclamo(Plan plan, String userId, String descripcion, String recurso) throws CampoInvalidoException {
        validar(plan, userId, descripcion);
        Reclamo r = new Reclamo(GeneradorId.generarIdSolicitud(), userId, plan.getId(), LocalDate.now(), descripcion, recurso);
        plan.addSolicitud(r);
        return r.getId();
    }

    public String crearSugerencia(Plan plan, String userId, String descripcion) throws CampoInvalidoException {
        validar(plan, userId, descripcion);
        Sugerencia s = new Sugerencia(GeneradorId.generarIdSolicitud(), userId, plan.getId(), LocalDate.now(), descripcion);
        plan.addSolicitud(s);
        return s.getId();
    }

    private void validar(Plan plan, String userId, String descripcion) throws CampoInvalidoException {
        if (plan == null) throw new PlanNoEncontradoException("desconocido");
        if (userId == null || userId.isEmpty()) throw new CampoInvalidoException("ID de usuario vacío");
        if (descripcion == null || descripcion.isEmpty()) throw new CampoInvalidoException("Descripción vacía");
    }

    public List<Solicitud> obtenerSolicitudesOrdenadas(Plan plan) {
        List<Solicitud> solicitudes = new ArrayList<>(plan.getSolicitudes());
        Collections.sort(solicitudes, (s1, s2) -> s1.getFechaRegistro().compareTo(s2.getFechaRegistro()));
        return solicitudes;
    }
}