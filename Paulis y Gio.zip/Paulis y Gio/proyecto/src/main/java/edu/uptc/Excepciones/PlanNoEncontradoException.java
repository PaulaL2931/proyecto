package edu.uptc.Excepciones;

public class PlanNoEncontradoException extends RuntimeException {
    public PlanNoEncontradoException(String id) {
        super("Plan con ID '" + id + "' no existe.");
    }
}