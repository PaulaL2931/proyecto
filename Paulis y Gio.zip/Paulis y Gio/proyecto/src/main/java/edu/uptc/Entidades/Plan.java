package edu.uptc.Entidades;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public abstract class Plan {
    protected String id;
    protected String usuarioId;
    protected LocalDate fechaAdquisicion;
    protected double valor;
    protected double descuentoMensualPct;
    protected List<Solicitud> solicitudes;

    public Plan(String id, String usuarioId, LocalDate fechaAdquisicion, double valor, double descuentoMensualPct) {
        this.id = id;
        this.usuarioId = usuarioId;
        this.fechaAdquisicion = fechaAdquisicion;
        this.valor = valor;
        this.descuentoMensualPct = descuentoMensualPct;
        this.solicitudes = new ArrayList<>();
    }

    public double valorNeto() {
        return valor - (valor * descuentoMensualPct / 100);
    }

    public void addSolicitud(Solicitud s) {
        solicitudes.add(s);
    }

    public List<Solicitud> getSolicitudes() {
        return solicitudes;
    }

    public String getId() {
        return id;
    }
}