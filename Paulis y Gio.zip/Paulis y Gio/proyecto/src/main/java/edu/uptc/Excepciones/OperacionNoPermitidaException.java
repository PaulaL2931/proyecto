package edu.uptc.Excepciones;

public class OperacionNoPermitidaException extends RuntimeException {
    public OperacionNoPermitidaException(String detalle) {
        super("Operación no permitida: " + detalle);
    }
}