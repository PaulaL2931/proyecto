package edu.uptc;

import edu.uptc.Gui.GuiWeCel;

public class Application {
    public static void main(String[] args) {
        GuiWeCel gui = new GuiWeCel();
        gui.iniciar();
    }
}