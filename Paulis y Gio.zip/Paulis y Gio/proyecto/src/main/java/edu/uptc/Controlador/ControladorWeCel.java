package edu.uptc.Controlador;

import edu.uptc.Entidades.*;
import edu.uptc.Entidades.Enums.*;
import edu.uptc.Excepciones.*;
import edu.uptc.Servicios.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public class ControladorWeCel {
    private final ServicioUsuario servicioUsuario = new ServicioUsuario();
    private final ServicioPlan servicioPlan = new ServicioPlan();
    private final ServicioSolicitud servicioSolicitud = new ServicioSolicitud();

    public void registrarCliente(String id, String nombre, String apellido, LocalDate fechaNacimiento,
                                 String pais, String estado, String ciudad, String password) throws CampoInvalidoException {
        servicioUsuario.registrarUsuario(id, nombre, apellido, fechaNacimiento, pais, estado, ciudad, Rol.CLIENTE, password);
    }

    public void registrarAsesor(String id, String nombre, String apellido, LocalDate fechaNacimiento,
                                String pais, String estado, String ciudad, String password) throws CampoInvalidoException {
        servicioUsuario.registrarUsuario(id, nombre, apellido, fechaNacimiento, pais, estado, ciudad, Rol.ASESOR, password);
    }

    public Usuario login(String id, String password) {
        return servicioUsuario.login(id, password);
    }

    public String crearPlanMovil(String userId, double valor, double descuento, int minutos, int gigas) throws CampoInvalidoException {
        Usuario usuario = servicioUsuario.obtenerUsuario(userId);
        return servicioPlan.crearPlanMovil(usuario, valor, descuento, minutos, gigas);
    }

    public String crearPlanHogar(String userId, double valor, double descuento, TipoTv tipoTv, int megas) throws CampoInvalidoException {
        Usuario usuario = servicioUsuario.obtenerUsuario(userId);
        return servicioPlan.crearPlanHogar(usuario, valor, descuento, tipoTv, megas);
    }

    public String crearPeticion(String userId, String planId, String descripcion) throws CampoInvalidoException {
        Usuario usuario = servicioUsuario.obtenerUsuario(userId);
        Plan plan = buscarPlan(usuario, planId);
        return servicioSolicitud.crearPeticion(plan, userId, descripcion);
    }

    public String crearQueja(String userId, String planId, String descripcion, int nivel) throws CampoInvalidoException {
        Usuario usuario = servicioUsuario.obtenerUsuario(userId);
        Plan plan = buscarPlan(usuario, planId);
        return servicioSolicitud.crearQueja(plan, userId, descripcion, nivel);
    }

    public String crearReclamo(String userId, String planId, String descripcion, String recurso) throws CampoInvalidoException {
        Usuario usuario = servicioUsuario.obtenerUsuario(userId);
        Plan plan = buscarPlan(usuario, planId);
        return servicioSolicitud.crearReclamo(plan, userId, descripcion, recurso);
    }

    public String crearSugerencia(String userId, String planId, String descripcion) throws CampoInvalidoException {
        Usuario usuario = servicioUsuario.obtenerUsuario(userId);
        Plan plan = buscarPlan(usuario, planId);
        return servicioSolicitud.crearSugerencia(plan, userId, descripcion);
    }

    private Plan buscarPlan(Usuario usuario, String planId) {
        Optional<Plan> planOpt = usuario.buscarPlanPorId(planId);
        if (planOpt.isEmpty()) throw new PlanNoEncontradoException(planId);
        return planOpt.get();
    }

    public void mostrarPlanes(String userId) {
        Usuario usuario = servicioUsuario.obtenerUsuario(userId);
        usuario.mostrarPlanes();
    }

    public List<Solicitud> obtenerSolicitudesOrdenadas(String planId) {
        for (Usuario usuario : servicioUsuario.getUsuarios().values()) {
            Optional<Plan> planOpt = usuario.buscarPlanPorId(planId);
            if (planOpt.isPresent()) {
                return servicioSolicitud.obtenerSolicitudesOrdenadas(planOpt.get());
            }
        }
        throw new PlanNoEncontradoException(planId);
    }

    public java.util.Map<String, Usuario> obtenerTodosUsuarios() {
        return servicioUsuario.getUsuarios();
    }

    public void marcarQuejaLeida(String planId, String solicitudId) {
        for (Usuario usuario : servicioUsuario.getUsuarios().values()) {
            Optional<Plan> planOpt = usuario.buscarPlanPorId(planId);
            if (planOpt.isPresent()) {
                Plan plan = planOpt.get();
                for (Solicitud sol : plan.getSolicitudes()) {
                    if (sol.getId().equals(solicitudId) && sol instanceof Queja) {
                        ((Queja) sol).marcarLeida();
                        return;
                    }
                }
            }
        }
        throw new SolicitudNoEncontradaException(solicitudId);
    }

    public void resolverPeticion(String planId, String solicitudId, String concepto) {
        for (Usuario usuario : servicioUsuario.getUsuarios().values()) {
            Optional<Plan> planOpt = usuario.buscarPlanPorId(planId);
            if (planOpt.isPresent()) {
                Plan plan = planOpt.get();
                for (Solicitud sol : plan.getSolicitudes()) {
                    if (sol.getId().equals(solicitudId) && sol instanceof Peticion) {
                        ((Peticion) sol).resolver(concepto);
                        return;
                    }
                }
            }
        }
        throw new SolicitudNoEncontradaException(solicitudId);
    }
}