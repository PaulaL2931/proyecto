package edu.uptc.Servicios;

import edu.uptc.Entidades.*;
import edu.uptc.Entidades.Enums.TipoTv;
import edu.uptc.Excepciones.*;
import edu.uptc.Utilidades.GeneradorId;

import java.time.LocalDate;

public class ServicioPlan {

    public String crearPlanMovil(Usuario usuario, double valor, double descuento, int minutos, int gigas) throws CampoInvalidoException {
        if (usuario == null) throw new UsuarioNoEncontradoException("desconocido");
        if (valor < 0 || descuento < 0) throw new CampoInvalidoException("Valor o descuento negativo");

        PlanMovil plan = new PlanMovil(GeneradorId.generarIdPlan(), usuario.getIdNumero(), LocalDate.now(),
                                       valor, descuento, minutos, gigas);
        usuario.addPlan(plan);
        return plan.getId();
    }

    public String crearPlanHogar(Usuario usuario, double valor, double descuento, TipoTv tipoTv, int megas) throws CampoInvalidoException {
        if (usuario == null) throw new UsuarioNoEncontradoException("desconocido");
        if (megas < 0) throw new CampoInvalidoException("Megas negativas");

        PlanHogar plan = new PlanHogar(GeneradorId.generarIdPlan(), usuario.getIdNumero(), LocalDate.now(),
                                       valor, descuento, tipoTv, megas);
        usuario.addPlan(plan);
        return plan.getId();
    }
}