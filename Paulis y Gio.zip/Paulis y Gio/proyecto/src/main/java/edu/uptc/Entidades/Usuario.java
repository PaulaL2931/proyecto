package edu.uptc.Entidades;

import edu.uptc.Entidades.Enums.Rol;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Usuario {
    private String idNumero;
    private String nombre;
    private String apellido;
    private LocalDate fechaNacimiento;
    private String pais;
    private String estado;
    private String ciudad;
    private Rol rol;
    private String password;
    private List<Plan> planes;

    public Usuario(String idNumero, String nombre, String apellido, LocalDate fechaNacimiento,
                   String pais, String estado, String ciudad, Rol rol, String password) {
        this.idNumero = idNumero;
        this.nombre = nombre;
        this.apellido = apellido;
        this.fechaNacimiento = fechaNacimiento;
        this.pais = pais;
        this.estado = estado;
        this.ciudad = ciudad;
        this.rol = rol;
        this.password = password;
        this.planes = new ArrayList<>();
    }

    public boolean checkPassword(String raw) {
        return password.equals(raw);
    }

    public void addPlan(Plan p) {
        planes.add(p);
    }

    public Optional<Plan> buscarPlanPorId(String planId) {
        return planes.stream().filter(p -> p.getId().equals(planId)).findFirst();
    }

    public void mostrarPlanes() {
        for (Plan p : planes) {
            System.out.println("ID: " + p.getId() + " | Valor neto: " + p.valorNeto());
        }
    }

    public String getIdNumero() {
        return idNumero;
    }

    public void setIdNumero(String idNumero) {
        this.idNumero = idNumero;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public Rol getRol() {
        return rol;
    }

    public void setRol(Rol rol) {
        this.rol = rol;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public List<Plan> getPlanes() {
        return planes;
    }

    public void setPlanes(List<Plan> planes) {
        this.planes = planes;
    }

   public String getNombreCompleto() {
    return nombre + " " + apellido;
    }
}