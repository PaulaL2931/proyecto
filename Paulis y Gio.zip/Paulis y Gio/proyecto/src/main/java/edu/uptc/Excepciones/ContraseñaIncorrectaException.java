package edu.uptc.Excepciones;

public class ContraseñaIncorrectaException extends RuntimeException {
    public ContraseñaIncorrectaException() {
        super("La contraseña ingresada es incorrecta.");
    }
}