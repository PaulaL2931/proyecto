package edu.uptc.Entidades;

import java.time.LocalDate;

public class PlanMovil extends Plan {
    private int minutos;
    private int gigasMensuales;

    public PlanMovil(String id, String usuarioId, LocalDate fechaAdquisicion, double valor,
                     double descuentoMensualPct, int minutos, int gigasMensuales) {
        super(id, usuarioId, fechaAdquisicion, valor, descuentoMensualPct);
        this.minutos = minutos;
        this.gigasMensuales = gigasMensuales;
    }

    public int getMinutos() {
        return minutos;
    }

    public int getGigasMensuales() {
        return gigasMensuales;
    }
}