package edu.uptc.Entidades;

import java.time.LocalDate;

public class Queja extends Solicitud {
    private int nivelInconformismo;
    private boolean leidaPorAsesor;

    public Queja(String id, String usuarioId, String planId, LocalDate fechaRegistro,
                 String descripcion, int nivelInconformismo) {
        super(id, usuarioId, planId, fechaRegistro, descripcion);
        this.nivelInconformismo = nivelInconformismo;
        this.leidaPorAsesor = false;
    }

    public void marcarLeida() {
        this.leidaPorAsesor = true;
    }

    public int getNivelInconformismo() {
        return nivelInconformismo;
    }

    public boolean isLeidaPorAsesor() {
        return leidaPorAsesor;
    }
}