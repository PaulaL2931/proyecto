package edu.uptc.Servicios;

import edu.uptc.Entidades.Usuario;
import edu.uptc.Entidades.Enums.Rol;
import edu.uptc.Excepciones.*;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

public class ServicioUsuario {
    private final Map<String, Usuario> usuarios = new HashMap<>();

    public void registrarUsuario(String id, String nombre, String apellido, LocalDate fechaNacimiento,
                                 String pais, String estado, String ciudad, Rol rol, String password) throws CampoInvalidoException {
        if (id == null || id.isEmpty()) throw new CampoInvalidoException("ID vacío");
        if (usuarios.containsKey(id)) throw new DatoDuplicadoException("usuario", id);
        if (password == null || password.length() < 4) throw new CampoInvalidoException("Contraseña inválida");

        Usuario nuevo = new Usuario(id, nombre, apellido, fechaNacimiento, pais, estado, ciudad, rol, password);
        usuarios.put(id, nuevo);
    }

    public Usuario login(String id, String password) {
        Usuario user = usuarios.get(id);
        if (user == null) throw new UsuarioNoEncontradoException(id);
        if (!user.checkPassword(password)) throw new ContraseñaIncorrectaException();
        return user;
    }

    public Usuario obtenerUsuario(String id) {
        Usuario user = usuarios.get(id);
        if (user == null) throw new UsuarioNoEncontradoException(id);
        return user;
    }

    public Map<String, Usuario> getUsuarios() {
        return usuarios;
    }
}