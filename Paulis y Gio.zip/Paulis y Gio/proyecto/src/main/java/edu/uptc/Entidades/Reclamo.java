package edu.uptc.Entidades;

import java.time.LocalDate;

public class Reclamo extends Solicitud {
    private String recursoCompensacion;

    public Reclamo(String id, String usuarioId, String planId, LocalDate fechaRegistro,
                   String descripcion, String recursoCompensacion) {
        super(id, usuarioId, planId, fechaRegistro, descripcion);
        this.recursoCompensacion = recursoCompensacion;
    }


    public String getRecursoCompensacion() {
        return recursoCompensacion;
    }
}