package edu.uptc.Excepciones;

public class CampoInvalidoException extends Exception {
    public CampoInvalidoException(String mensaje) {
        super("Campo inválido: " + mensaje);
    }
}