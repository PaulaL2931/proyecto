package edu.uptc.Excepciones;

public class UsuarioNoEncontradoException extends RuntimeException {
    public UsuarioNoEncontradoException(String id) {
        super("Usuario con ID '" + id + "' no encontrado.");
    }
}