package edu.uptc.Gui;

import edu.uptc.Controlador.ControladorWeCel;
import edu.uptc.Entidades.Usuario;
import edu.uptc.Entidades.Enums.TipoTv;
import edu.uptc.Entidades.Enums.Rol;
import edu.uptc.Entidades.Solicitud;

import javax.swing.*;
import java.time.LocalDate;
import java.util.List;

public class GuiWeCel {
    private final ControladorWeCel sistema = new ControladorWeCel();
    private Usuario usuarioActual;

    public void iniciar() {
        while (true) {
            String[] opciones = {"Registrar Cliente", "Iniciar Sesión", "Salir"};
            int opcion = JOptionPane.showOptionDialog(null, "Bienvenido a WeCel", "Menú Principal",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, opciones, opciones[0]);

            switch (opcion) {
                case 0 -> registrarCliente();
                case 1 -> login();
                case 2 -> System.exit(0);
                default -> JOptionPane.showMessageDialog(null, "Opción no válida");
            }
        }
    }

    private void registrarCliente() {
        try {
            String id = JOptionPane.showInputDialog("Número de identificación:");
            String nombre = JOptionPane.showInputDialog("Nombre:");
            String apellido = JOptionPane.showInputDialog("Apellido:");
            LocalDate fecha = LocalDate.parse(JOptionPane.showInputDialog("Fecha de nacimiento (YYYY-MM-DD):"));
            String pais = JOptionPane.showInputDialog("País:");
            String estado = JOptionPane.showInputDialog("Estado:");
            String ciudad = JOptionPane.showInputDialog("Ciudad:");
            String password = JOptionPane.showInputDialog("Contraseña:");

            sistema.registrarCliente(id, nombre, apellido, fecha, pais, estado, ciudad, password);
            JOptionPane.showMessageDialog(null, "Cliente registrado exitosamente.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }

    private void login() {
        try {
            String id = JOptionPane.showInputDialog("Ingrese su ID:");
            String password = JOptionPane.showInputDialog("Ingrese su contraseña:");
            usuarioActual = sistema.login(id, password);
            JOptionPane.showMessageDialog(null, "Bienvenido, " + usuarioActual.getNombreCompleto());
            
            // Check user role and show appropriate menu
            if (usuarioActual.getRol() == Rol.ASESOR) {
                menuAsesor();
            } else {
                menuUsuario();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }

    private void menuUsuario() {
        while (true) {
            String[] opciones = {"Crear Plan Móvil", "Crear Plan Hogar", "Crear Petición", "Crear Queja", 
                                 "Crear Reclamo", "Crear Sugerencia", "Ver Planes", "Ver PQRS Ordenadas", "Salir"};
            int opcion = JOptionPane.showOptionDialog(null, "Menú de Usuario", "Opciones",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, opciones, opciones[0]);

            switch (opcion) {
                case 0 -> crearPlanMovil();
                case 1 -> crearPlanHogar();
                case 2 -> crearPeticion();
                case 3 -> crearQueja();
                case 4 -> crearReclamo();
                case 5 -> crearSugerencia();
                case 6 -> sistema.mostrarPlanes(usuarioActual.getIdNumero());
                case 7 -> verPQRSOrdenadas();
                case 8 -> { return; }
                default -> JOptionPane.showMessageDialog(null, "Opción no válida");
            }
        }
    }

    private void crearPlanMovil() {
        try {
            double valor = Double.parseDouble(JOptionPane.showInputDialog("Valor del plan:"));
            double descuento = Double.parseDouble(JOptionPane.showInputDialog("Descuento (%):"));
            int minutos = Integer.parseInt(JOptionPane.showInputDialog("Minutos incluidos:"));
            int gigas = Integer.parseInt(JOptionPane.showInputDialog("Gigas mensuales:"));

            String id = sistema.crearPlanMovil(usuarioActual.getIdNumero(), valor, descuento, minutos, gigas);
            JOptionPane.showMessageDialog(null, "Plan móvil creado con ID: " + id);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }

    private void crearPlanHogar() {
        try {
            double valor = Double.parseDouble(JOptionPane.showInputDialog("Valor del plan:"));
            double descuento = Double.parseDouble(JOptionPane.showInputDialog("Descuento (%):"));
            String[] tipos = {"DIGITAL", "ANALOGA"};
            String tipo = (String) JOptionPane.showInputDialog(null, "Tipo de TV:", "Seleccionar",
                    JOptionPane.QUESTION_MESSAGE, null, tipos, tipos[0]);
            int megas = Integer.parseInt(JOptionPane.showInputDialog("Megas de internet:"));

            TipoTv tipoTv = TipoTv.valueOf(tipo);
            String id = sistema.crearPlanHogar(usuarioActual.getIdNumero(), valor, descuento, tipoTv, megas);
            JOptionPane.showMessageDialog(null, "Plan hogar creado con ID: " + id);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }

    private void crearPeticion() {
        try {
            String planId = JOptionPane.showInputDialog("Ingrese el ID del plan:");
            String descripcion = JOptionPane.showInputDialog("Descripción de la petición:");

            String id = sistema.crearPeticion(usuarioActual.getIdNumero(), planId, descripcion);
            JOptionPane.showMessageDialog(null, "Petición creada con ID: " + id);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }

    private void crearQueja() {
        try {
            String planId = JOptionPane.showInputDialog("Ingrese el ID del plan:");
            String descripcion = JOptionPane.showInputDialog("Descripción de la queja:");
            int nivel = Integer.parseInt(JOptionPane.showInputDialog("Nivel de inconformismo (1-5):"));

            String id = sistema.crearQueja(usuarioActual.getIdNumero(), planId, descripcion, nivel);
            JOptionPane.showMessageDialog(null, "Queja creada con ID: " + id);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }

    private void crearReclamo() {
        try {
            String planId = JOptionPane.showInputDialog("Ingrese el ID del plan:");
            String descripcion = JOptionPane.showInputDialog("Descripción del reclamo:");
            String recurso = JOptionPane.showInputDialog("Recurso de compensación:");

            String id = sistema.crearReclamo(usuarioActual.getIdNumero(), planId, descripcion, recurso);
            JOptionPane.showMessageDialog(null, "Reclamo creado con ID: " + id);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }

    private void crearSugerencia() {
        try {
            String planId = JOptionPane.showInputDialog("Ingrese el ID del plan:");
            String descripcion = JOptionPane.showInputDialog("Descripción de la sugerencia:");

            String id = sistema.crearSugerencia(usuarioActual.getIdNumero(), planId, descripcion);
            JOptionPane.showMessageDialog(null, "Sugerencia creada con ID: " + id);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }

    private void verPQRSOrdenadas() {
        try {
            String planId = JOptionPane.showInputDialog("Ingrese el ID del plan:");
            List<Solicitud> solicitudes = sistema.obtenerSolicitudesOrdenadas(planId);
            
            if (solicitudes.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No hay solicitudes para este plan");
                return;
            }
            
            StringBuilder sb = new StringBuilder("SOLICITUDES ORDENADAS (Más antigua a más reciente):\n\n");
            for (Solicitud sol : solicitudes) {
                sb.append("ID: ").append(sol.getId()).append("\n");
                sb.append("Fecha: ").append(sol.getFechaRegistro()).append("\n");
                sb.append("Descripción: ").append(sol.getDescripcion()).append("\n");
                sb.append("---\n");
            }
            
            JOptionPane.showMessageDialog(null, sb.toString(), "PQRS Ordenadas", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }

    private void menuAsesor() {
        while (true) {
            String[] opciones = {"Ver todas las PQRS", "Marcar Queja como Leída", "Resolver Petición", "Salir"};
            int opcion = JOptionPane.showOptionDialog(null, "Menú de Asesor", "Gestión de PQRS",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, opciones, opciones[0]);

            switch (opcion) {
                case 0 -> verTodasPQRS();
                case 1 -> marcarQuejaLeida();
                case 2 -> resolverPeticion();
                case 3 -> { return; }
                default -> JOptionPane.showMessageDialog(null, "Opción no válida");
            }
        }
    }

    private void verTodasPQRS() {
        try {
            StringBuilder sb = new StringBuilder("TODAS LAS SOLICITUDES DEL SISTEMA:\n\n");
            java.util.Map<String, Usuario> usuarios = sistema.obtenerTodosUsuarios();
            
            for (Usuario usuario : usuarios.values()) {
                sb.append("Usuario: ").append(usuario.getNombreCompleto()).append(" (").append(usuario.getIdNumero()).append(")\n");
                for (edu.uptc.Entidades.Plan plan : usuario.getPlanes()) {
                    List<Solicitud> solicitudes = sistema.obtenerSolicitudesOrdenadas(plan.getId());
                    for (Solicitud sol : solicitudes) {
                        sb.append("  - ").append(sol.getId()).append(" (").append(sol.getFechaRegistro()).append("): ").append(sol.getDescripcion()).append("\n");
                    }
                }
            }
            
            JOptionPane.showMessageDialog(null, sb.toString(), "Todas las PQRS", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }

    private void marcarQuejaLeida() {
        try {
            String planId = JOptionPane.showInputDialog("Ingrese el ID del plan:");
            String solicitudId = JOptionPane.showInputDialog("Ingrese el ID de la queja:");
            
            sistema.marcarQuejaLeida(planId, solicitudId);
            JOptionPane.showMessageDialog(null, "Queja marcada como leída");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }

    private void resolverPeticion() {
        try {
            String planId = JOptionPane.showInputDialog("Ingrese el ID del plan:");
            String solicitudId = JOptionPane.showInputDialog("Ingrese el ID de la petición:");
            String concepto = JOptionPane.showInputDialog("Ingrese el concepto de solución:");
            
            sistema.resolverPeticion(planId, solicitudId, concepto);
            JOptionPane.showMessageDialog(null, "Petición resuelta");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }
}