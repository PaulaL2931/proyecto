package edu.uptc.Entidades;

import java.time.LocalDate;

public class Peticion extends Solicitud {
    private boolean resuelta;
    private String conceptoSolucion;

    public Peticion(String id, String usuarioId, String planId, LocalDate fechaRegistro, String descripcion) {
        super(id, usuarioId, planId, fechaRegistro, descripcion);
        this.resuelta = false;
        this.conceptoSolucion = "";
    }

    public void resolver(String concepto) {
        this.resuelta = true;
        this.conceptoSolucion = concepto;
    }

    public boolean isResuelta() {
        return resuelta;
    }
    public String getConceptoSolucion() {
        return conceptoSolucion;
    }
}