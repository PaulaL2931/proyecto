package edu.uptc.Servicios;

import edu.uptc.Entidades.*;
import edu.uptc.Excepciones.CampoInvalidoException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ServicioSolicitudTest {
    private ServicioSolicitud servicio;
    private Plan plan;

    @BeforeEach
    void setUp() {
        servicio = new ServicioSolicitud();
        plan = new PlanMovil("PLAN-1000", "123", LocalDate.now(), 50.0, 10.0, 300, 5);
    }

    /** 
     * @throws CampoInvalidoException
     */
    @Test
    void testCrearPeticion() throws CampoInvalidoException {
        String id = servicio.crearPeticion(plan, "123", "Descripción test");
        assertNotNull(id);
        assertEquals(1, plan.getSolicitudes().size());
    }

    /** 
     * @throws CampoInvalidoException
     */
    @Test
    void testCrearQueja() throws CampoInvalidoException {
        String id = servicio.crearQueja(plan, "123", "Queja test", 3);
        assertNotNull(id);
        assertEquals(1, plan.getSolicitudes().size());
    }

    /** 
     * @throws CampoInvalidoException
     */
    @Test
    void testCrearReclamo() throws CampoInvalidoException {
        String id = servicio.crearReclamo(plan, "123", "Reclamo test", "$100");
        assertNotNull(id);
        assertEquals(1, plan.getSolicitudes().size());
    }

    /** 
     * @throws CampoInvalidoException
     */
    @Test
    void testCrearSugerencia() throws CampoInvalidoException {
        String id = servicio.crearSugerencia(plan, "123", "Sugerencia test");
        assertNotNull(id);
        assertEquals(1, plan.getSolicitudes().size());
    }

    @Test
    void testCrearSolicitudConPlanNulo() {
        assertThrows(Exception.class, () ->
            servicio.crearPeticion(null, "123", "Descripción")
        );
    }

    @Test
    void testCrearSolicitudConUsuarioVacio() {
        assertThrows(CampoInvalidoException.class, () ->
            servicio.crearPeticion(plan, "", "Descripción")
        );
    }

    /** 
     * @throws CampoInvalidoException
     */
    @Test
    void testObtenerSolicitudesOrdenadas() throws CampoInvalidoException {
        servicio.crearPeticion(plan, "123", "Petición");
        servicio.crearQueja(plan, "123", "Queja", 3);
        servicio.crearReclamo(plan, "123", "Reclamo", "$100");
        
        List<Solicitud> ordenadas = servicio.obtenerSolicitudesOrdenadas(plan);
        
        assertEquals(3, ordenadas.size());
        for (int i = 1; i < ordenadas.size(); i++) {
            assertTrue(ordenadas.get(i-1).getFechaRegistro().compareTo(
                      ordenadas.get(i).getFechaRegistro()) <= 0);
        }
    }

    @Test
    void testObtenerSolicitudesVacias() {
        List<Solicitud> ordenadas = servicio.obtenerSolicitudesOrdenadas(plan);
        assertEquals(0, ordenadas.size());
    }

    @ParameterizedTest
    @CsvSource({
        "Descripción petición 1",
        "Descripción petición 2",
        "Descripción petición 3"
    })
    void testCrearPeticionParametrizado(String descripcion) throws CampoInvalidoException {
        String id = servicio.crearPeticion(plan, "123", descripcion);
        assertNotNull(id);
        assertEquals(1, plan.getSolicitudes().size());
        assertEquals(descripcion, plan.getSolicitudes().get(0).getDescripcion());
    }

    @ParameterizedTest
    @CsvSource({
        "Queja nivel 1, 1",
        "Queja nivel 3, 3",
        "Queja nivel 5, 5"
    })
    void testCrearQuejaParametrizado(String descripcion, int nivel) throws CampoInvalidoException {
        String id = servicio.crearQueja(plan, "123", descripcion, nivel);
        assertNotNull(id);
        assertEquals(1, plan.getSolicitudes().size());
        Queja queja = (Queja) plan.getSolicitudes().get(0);
        assertEquals(nivel, queja.getNivelInconformismo());
    }

    @ParameterizedTest
    @CsvSource({
        "Reclamo descripción 1, $100",
        "Reclamo descripción 2, $200",
        "Reclamo descripción 3, $500"
    })
    void testCrearReclamoParametrizado(String descripcion, String recurso) throws CampoInvalidoException {
        String id = servicio.crearReclamo(plan, "123", descripcion, recurso);
        assertNotNull(id);
        assertEquals(1, plan.getSolicitudes().size());
        Reclamo reclamo = (Reclamo) plan.getSolicitudes().get(0);
        assertEquals(recurso, reclamo.getRecursoCompensacion());
    }
}
