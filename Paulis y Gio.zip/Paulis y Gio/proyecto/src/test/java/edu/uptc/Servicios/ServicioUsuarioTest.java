package edu.uptc.Servicios;

import edu.uptc.Entidades.Enums.Rol;
import edu.uptc.Excepciones.CampoInvalidoException;
import edu.uptc.Excepciones.DatoDuplicadoException;
import edu.uptc.Excepciones.UsuarioNoEncontradoException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for ServicioUsuario class
 * Tests user registration, authentication, and validation
 */
class ServicioUsuarioTest {
    private ServicioUsuario servicio;

    @BeforeEach
    void setUp() {
        servicio = new ServicioUsuario();
    }

    /** 
     * @throws CampoInvalidoException
     */
    @Test
    void testRegistrarClienteExitoso() throws CampoInvalidoException {
        assertDoesNotThrow(() -> 
            servicio.registrarUsuario("123", "Juan", "Pérez", LocalDate.of(1990, 5, 15), 
                                     "Colombia", "Boyacá", "Tunja", Rol.CLIENTE, "pass1234")
        );
        assertNotNull(servicio.obtenerUsuario("123"));
    }

    @Test
    void testRegistrarClienteConIDVacio() {
        assertThrows(CampoInvalidoException.class, () ->
            servicio.registrarUsuario("", "Juan", "Pérez", LocalDate.of(1990, 5, 15),
                                     "Colombia", "Boyacá", "Tunja", Rol.CLIENTE, "pass1234")
        );
    }

    /** 
     * @throws CampoInvalidoException
     */
    @Test
    void testRegistrarClienteDuplicado() throws CampoInvalidoException {
        servicio.registrarUsuario("123", "Juan", "Pérez", LocalDate.of(1990, 5, 15),
                                 "Colombia", "Boyacá", "Tunja", Rol.CLIENTE, "pass1234");
        
        assertThrows(DatoDuplicadoException.class, () ->
            servicio.registrarUsuario("123", "Carlos", "López", LocalDate.of(1985, 3, 20),
                                     "Colombia", "Cundinamarca", "Bogotá", Rol.CLIENTE, "pass5678")
        );
    }

    @Test
    void testRegistrarConContraseñaMuyCorta() {
        assertThrows(CampoInvalidoException.class, () ->
            servicio.registrarUsuario("456", "María", "García", LocalDate.of(1995, 8, 10),
                                     "Colombia", "Valle", "Cali", Rol.CLIENTE, "123")
        );
    }

    /** 
     * @throws CampoInvalidoException
     */
    @Test
    void testLoginExitoso() throws CampoInvalidoException {
        servicio.registrarUsuario("789", "Pedro", "Martínez", LocalDate.of(1988, 12, 5),
                                 "Colombia", "Cauca", "Popayán", Rol.ASESOR, "pass9876");
        
        assertNotNull(servicio.login("789", "pass9876"));
    }

    @Test
    void testLoginUsuarioNoEncontrado() {
        assertThrows(UsuarioNoEncontradoException.class, () ->
            servicio.login("999", "pass1234")
        );
    }

    /** 
     * @throws CampoInvalidoException
     */
    @Test
    void testObtenerUsuario() throws CampoInvalidoException {
        servicio.registrarUsuario("111", "Luis", "Rodríguez", LocalDate.of(1992, 7, 22),
                                 "Colombia", "Atlántico", "Barranquilla", Rol.CLIENTE, "pass1111");
        
        assertNotNull(servicio.obtenerUsuario("111"));
        assertEquals("Luis", servicio.obtenerUsuario("111").getNombre());
    }

    @ParameterizedTest
    @CsvSource({
        "user001, pass1234, true",
        "user002, pass5678, true",
        "user003, pass9999, true",
        "user999, invalidPass, false"
    })
    void testLoginParametrizado(String idUsuario, String password, boolean debeExistir) throws CampoInvalidoException {
        if (debeExistir) {
            servicio.registrarUsuario(idUsuario, "Usuario", "Prueba", LocalDate.of(1990, 1, 1),
                                     "Colombia", "Bogotá", "Bogotá", Rol.CLIENTE, password);
            assertNotNull(servicio.login(idUsuario, password));
        } else {
            assertThrows(UsuarioNoEncontradoException.class, () ->
                servicio.login(idUsuario, password)
            );
        }
    }

    @ParameterizedTest
    @CsvSource({
        "id001, pass1234, CLIENTE",
        "id002, pass5678, ASESOR",
        "id003, pass9999, CLIENTE"
    })
    void testRegistrarUsuarioParametrizado(String id, String password, String rol) throws CampoInvalidoException {
        Rol rolEnum = Rol.valueOf(rol);
        servicio.registrarUsuario(id, "Nombre", "Apellido", LocalDate.of(1990, 5, 15),
                                 "Colombia", "Boyacá", "Tunja", rolEnum, password);
        
        assertNotNull(servicio.obtenerUsuario(id));
        assertEquals(rolEnum, servicio.obtenerUsuario(id).getRol());
    }

    @ParameterizedTest
    @CsvSource({
        "pass1",
        "pa",
        ""
    })
    void testRegistrarConContraseñaInvalidaParametrizado(String password) {
        assertThrows(CampoInvalidoException.class, () ->
            servicio.registrarUsuario("user123", "Juan", "Pérez", LocalDate.of(1990, 5, 15),
                                     "Colombia", "Boyacá", "Tunja", Rol.CLIENTE, password)
        );
    }
}
